<?php 
$host = 'localhost'; 
$user = 'root';  // ตั้งค่า User ให้ตรงกับ MYSQL
$pass = 'abc12345';// ตั้งค่า passให้ตรงกับ MYSQL
$db = 'low'; // ตั้งค่า db ให้ตรงกับ MYSQL
$con = mysqli_connect($host,$user,$pass,$db); 
mysqli_set_charset($con,'utf8');
?>