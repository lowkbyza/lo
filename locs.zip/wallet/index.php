﻿<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
</head>
<body>
<div class="container">
<div class="row">
<form action="check.php" method="post">
	<div class="form-group">
		<h2>ชื่อผู้ใช้งาน(Username)</h2>
		<input type="text" class="form-control" name="user">
	</div>
		<input type="submit" class="btn btn-success" value="เติมเงิน">
</form>
</div> 
<p>truemoney wallet auto เพียงแค่นำหมายเลขอ้างอิงมาใส่</p>
<p>เบอร์ wallet:0962630727 (Pichet Buanuan)</p>
<p>ราคาที่เติม 10 =10 เครดิต</p>
<p>ราคาที่เติม 20 =20 เครดิต</p>
<p>ราคาที่เติม 30 =30 เครดิต</p>
<p>ราคาที่เติม 40 =40 เครดิต</p>
<p>ราคาที่เติม 50 =50 เครดิต</p>
<p>ราคาที่เติม 60 =60 เครดิต</p>
<p>ราคาที่เติม 70 =70 เครดิต</p>
<p>ราคาที่เติม 80 =80 เครดิต</p>
<p>ราคาที่เติม 90 =180 เครดิต</p>
<p>ราคาที่เติม 100 =200 เครดิต</p>
<p>ราคาที่เติม 150 =300 เครดิต</p>
<p>ราคาที่เติม 300 =600 เครดิต</p>
<p>ราคาที่เติม 500 =500 เครดิต</p>
<p>ราคาที่เติม 1000 =2000 เครดิต</p>
<p>&nbsp;</p>
</div>
<body>
</html>