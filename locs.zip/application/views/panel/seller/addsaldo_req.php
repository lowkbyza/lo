<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
	 <div class="row">
        <div class="col-lg-12">
            <section class="content-header">
      <h2>
       เติมเงินเข้าระบบ
      </h2>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">Auto TrueWallet</li>
    </ol>
    </section>
			<div class="dropdown pull-right">
					<a href="<?= base_url('panel/reseller/'.str_replace(' ','-',$_SESSION['username']).'/addsaldo-via-hp') ?>" class="btn btn-danger" ><span class="fa fa-credit-card"></span> ผ่านธนาคาร</a>
            </div>
<div class="row">
       <div class="col-xs-6 col-md-5 col-md-4 col-lg-3">
            <div class="btn btn-primary" class="well">เครดิต : <B><?= $user -> saldo ?></B></div>
        </div>
    </div>
            <p>&nbsp;</p>
<div class="well">
<p>
                </form>
                <div align="center">
<tr><center>
<td>
<p><span class="btn label-warning">ระบบเติมเงินอัตโนมัติ </span></p>

  <form method="post" action="/wallet/check.php"><strong><br />
  <p> โอน TrueWallet มาที่เบอร์ </p>
  <font color="red">0962630727</font>
  <h5></h5>
  <p> แล้วก็นำเลขที่อ้างอิงมายืนยันเพื่อเติมเครดิต </p>
  <p> จำนวนที่สามารถแจ้งอ้อโต้ได้มีดังนี้ </p>
  <p><font color="#FF7300"> ไม่มีขั้นต่ำ โอนได้สูงสุด 300 บาท </font></p>
  <input name="user"type="text" class="form-control text-center" id="user"  style="width:110px; border:5px #000000" value="<?= $_SESSION['username'] ?>" maxlength="14"input type="text" name="text1" readonly />
  <br />
  <input class="btn btn-primary" type="submit" value="คลิกเพื่อยืนยันเลขที่อ้างอิง" />
  <p>&nbsp;</p>
  <p>>>> เครดิตจะเพิ่มโดยอัตโนมัต <<<</p>
  <p><a href="https://m.me/GengPichet">แจ้งปัญหาคลิกที่นี่...</a></p>
<center><p></center>
</td>
  </center>
  </tr>
  </center>
  </div>  
  </p>
</p>
</div>
            
            
            
            
            
            
            
            
        </div>
    </div>
  <div class="row">
		  <div class="col-sm-6"></div>
    </div>
</div>  
<br />
