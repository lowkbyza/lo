<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2>
       รายการเซิร์ฟเวอร์
      </h2>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">เซิฟร์เวอร์</li>
		
		
		
		
		<div class="tab-pane active" id="tab_1-1">
                             <h3><b>  </b></h3>	
                     <br><br><p><b> ชี้แจง !!</b></p>
	
												
ลูกค้าต้องทำการสมัครโปรชั่นเสริมก่อนดังนี้ จึงจะใช้งานได้<br><br>

📶 ทรูมูฟ สมัครTrueID👇👇<br>
9บาท / 1วัน +VAT=9.63บาท กด*900*3956# 📞<br>
19บาท / 7วัน +VAT=20.33บาท กด*900*3957# 📞<br>
59บาท / 30วัน +VAT=63.13บาท กด*900*3958# 📞<br>
📶 ดีแทค สมัครโปรLine👇👇<br>
5บาท / 1วัน +VAT=5.35บาท กด*104*431# 📞<br>
19บาท / 7วัน +VAT=20.33บาท กด*104*421# 📞<br>
49บาท / 30วัน +VAT=52.43บาท กด*104*432# 📞<br><br>

												
                            </div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
    </ol>
    </section>
            <div class="dropdown pull-right">
					<a href="<?= base_url('wallet') ?>" class="btn btn-warning" ><span class="fa fa-btc fa-fw"></span> เติมเครดิต</a>
            </div>
<div class="row">
       <div class="col-xs-6 col-md-5 col-md-4 col-lg-3">
            <div class="btn btn-primary" class="well">เครดิต : <B><?= $user -> saldo ?></B></div>
        </div>
    </div>
    <p>&nbsp;</p> 
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
            </div>
        <?php foreach($server as $row): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <b><span class="fa fa-send fa-fw"></span> <?= $row['ServerName']?></b> <?php if ($row['Status']) { echo '';} else {echo "(บัญชีเต็มแล้ว)";}?>
                    </div>
                    <table class="table">
                        <tr>
                            <td>ที่ตั้งเซิฟร์</td><td>: <?= $row['Location']?></b></td>
                        </tr>
                        <tr>
                            <td>โฮส IP</td><td>: แสดงหลังจากซื้อแพ็คเกจ</b></td>
                        </tr>
                        <tr>
                            <td>ระยะเวลาใช้งาน</td><td>: <?= $row['Expired']?> วัน</td>
                        </tr>
                        <tr>
                            <td>ราคา</td><td>: <?= $row['Price']?> บาท</b></td>
                        </tr>
                    </table>
  
                    <div class="panel-footer text-left">
                        <a href="<?= base_url('panel/seller/'.$_SESSION['username'].'/buy/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id']) ?>" class="btn btn-success"><i class="fa fa-shopping-cart fa-fw"></i> ซื้อแพ็กเกจ</a>
						<a href="http://<?= $row['HostName']?>:81/ConfigPanel/SpeedVPN.ovpn" class="btn btn-danger"><i class="fa fa-download fa-fw"></i> Ovpn</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
